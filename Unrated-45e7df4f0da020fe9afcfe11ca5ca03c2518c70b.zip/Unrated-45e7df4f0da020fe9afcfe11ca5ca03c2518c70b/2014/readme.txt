ah?
no news is good news.